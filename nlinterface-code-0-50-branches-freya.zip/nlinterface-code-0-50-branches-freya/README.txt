Quickstart Freya (using Mooney geography) 

1. Update freya.properties to point to your repositoryURL and repositoryId.
   - you can find mooney ontology in freya-annotate/src/main/resources/ontologies/mooney folder
   - it is recommended to use owlimlite with owlimhorst when setting up repository
2. mvn clean install will create war file in freya-annotate/target directory and run all tests
3. Copy war file into your tomcat webapps folder and start tomcat.
4. Open it: http://localhost:8080/freya

----------------------------------------
Using freya with other ontologies
1. Run IndexTriplesExec.java > this will create lucene index on your classpath using ther repository 
identified by repositoryURL and repositoryId