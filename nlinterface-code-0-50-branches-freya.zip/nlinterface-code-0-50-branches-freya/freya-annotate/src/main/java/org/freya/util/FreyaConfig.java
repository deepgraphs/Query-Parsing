package org.freya.util;

public class FreyaConfig {

    public static final boolean useCashedOntologyToMap=false;
    
}
