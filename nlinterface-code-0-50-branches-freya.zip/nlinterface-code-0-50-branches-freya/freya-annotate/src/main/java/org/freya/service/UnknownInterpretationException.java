package org.freya.service;

public class UnknownInterpretationException extends Exception {
  public UnknownInterpretationException(String message) {
    super(message);
  }
}
