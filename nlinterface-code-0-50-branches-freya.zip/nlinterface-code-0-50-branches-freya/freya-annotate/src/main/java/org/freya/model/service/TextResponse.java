package org.freya.model.service;

public class TextResponse {

}
