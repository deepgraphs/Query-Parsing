package org.freya.model;

public class MainSubject {
//	Annotation annotation = new Annotation();
//	List<Tree> tree;
//
//	public List<Tree> getTree() {
//		return tree;
//	}
//
//	public void setTree(List<Tree> tree) {
//		this.tree = tree;
//	}
//
//	public Annotation getAnnotation() {
//		return annotation;
//	}
//
//	public void setAnnotation(Annotation annotation) {
//		this.annotation = annotation;
//	}

	/*
	 * defines the priority for the main subject: for example, if we want to
	 * give priority to the main subject wrt the ontology concepts e.g. in cases
	 * of 'how long' when long is a mountain
	 */
	Integer priority;

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

//	MainSubject head;
//	List<String> modifiers;
//
//
//	public MainSubject getHead() {
//		return head;
//	}
//
//	public void setHead(MainSubject head) {
//		this.head = head;
//	}
//
//	public List<String> getModifiers() {
//		return modifiers;
//	}
//
//	public void setModifiers(List<String> modifiers) {
//		this.modifiers = modifiers;
//	}

	
}
